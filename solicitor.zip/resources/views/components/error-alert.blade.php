<div style="display: none;" id="mail_fail">
    <div class="alert alert-dark alert-dismissible fade show" role="alert">
        <strong>Error!</strong> <span id="error-message">{{ $message ?? 'An error occurred while sending your message.' }}</span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>