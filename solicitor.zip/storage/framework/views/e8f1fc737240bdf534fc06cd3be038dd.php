<div class="container">
    <div class="row g-4 align-items-center">
        <div class="col-lg-6">
            &copy; © 2024 Acacia Solicitors. All Rights Reserved.
        </div>
        <div class="col-lg-6 text-lg-end">
            <div class="social-icons">
                <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                <a href="#"><i class="fa fa-rss fa-lg"></i></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\solicitor\resources\views/components/sub-footer.blade.php ENDPATH**/ ?>