<div class="col-md-6 offset-md-3" style="display: none;" id="mail_success">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <h4 class="alert-heading">Well done!</h4>
        <p>{{ $message ?? 'Your message has been sent successfully!' }}</p>
        <hr>
        <p class="mb-0">We'll get back to you as soon as possible.</p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>