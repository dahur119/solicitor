<section id="subheader" class="jarallax text-white">
    <img src="images/background/subheader2.jpg" class="jarallax-img" alt="">
    <div class="center-y relative text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1>Contact Us</h1>
                    <p>Reputation. Respect. Result.</p>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</section>